//
//  TrackableTableViewController.h
//  UserSDK
//
//  Created by Damian Kłobukowski on 04/08/2020.
//  Copyright © 2020 Andrzej Puczyk. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TrackableTableViewController : UITableViewController

@end

NS_ASSUME_NONNULL_END
